/*
Copyright (C) 2009 - 2019 Broadleaf Commerce.

Licensed under the Broadleaf End User License Agreement (EULA),
Version 1.1 (the “Commercial License” located at
http://license.broadleafcommerce.org/commercial_license-1.1.txt).

Alternatively, the Commercial License may be replaced with a mutually
agreed upon license (the “Custom License”) between you and
Broadleaf Commerce. You may not use this file except in compliance
with the applicable license.
*/
function parseSearch(queryString) {
  if (queryString.indexOf('?') === 0) {
    queryString = queryString.substring(1);
  }

  var params = {},
    queries,
    temp,
    i,
    l;

  queries = queryString.split('&');

  for (i = 0, l = queries.length; i < l; i++) {
    temp = queries[i].split('=');
    params[temp[0]] = decodeURIComponent(temp[1]);
  }

  return params;
}

window.parent.postMessage(
  { type: 'authorization_code', response: parseSearch(window.location.search) },
  window.location.origin
);
