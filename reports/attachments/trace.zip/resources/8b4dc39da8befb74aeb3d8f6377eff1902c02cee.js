window.global = window;
window.__env = {
  NODE_ENV: "development",
  VITE_ENABLE_PKCE: "true",
  VITE_ENABLE_DEV_SETTINGS: "false",
}
